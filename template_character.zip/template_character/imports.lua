local includes = {}

function includes:Init(mod)
  -- do your inits here
end

return includes